#!/bin/bash
################################################################################
#
# Scrip Created by http://CryptoLions.io
# For EOS mainnet
#
# https://github.com/CryptoLions/EOS-MainNet
#
###############################################################################

NODEOSBINDIR="."
DATADIR=`pwd`

echo -e "Starting Roxe \n";

#ulimit -c unlimited
#ulimit -n 65535
#ulimit -s 64000

while [ 1 -eq 1 ]; do
    echo "startat" `date +"%Y-%m-%d %H:%M:%S"` >> $DATADIR/stderr.txt
    $NODEOSBINDIR/nodroxe --data-dir $DATADIR/node  --genesis-json $DATADIR/genesis.json  --config-dir $DATADIR "$@" >> $DATADIR/stdout.txt 2>> $DATADIR/stderr.txt
    #echo $! > $DATADIR/nodactc.pid
    sleep 10
#    curl http://172.16.213.97:5566/sms?content=restart_eos2
done
